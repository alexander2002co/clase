<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=euc-jp">
	<title>TCIS: Informe Maquinaria Buque</title>
	<link rel="stylesheet" type="text/css" href="../contenido/general.css">
</head>
<body>
	<div id="ext">
		<div id="logo">
			<img src="contenido/img/TECEEC.png" id="logoti">
		</div>
		<div id="login">
			<h1>Informe  </h1>
			<iframe src="https://docs.google.com/spreadsheets/d/1fpi0SDV__MMrY6e0dcB1kFfgBS8-7t1vOAZi65KvDfA/edit?usp=sharing" width="700" height="520" frameborder="0" marginheight="0" marginwidth="0">Cargando…</iframe> 
			 
		</div>
	 
	<div id="login">
			<form method="post">
				<input type="submit" value="Regresar" formaction="menupalermo.php"> 
	</div>
</body>
</html>